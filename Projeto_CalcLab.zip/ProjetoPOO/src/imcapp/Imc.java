
package imcapp;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Imc 
{
    private double altura;
    private double peso;
    
    
    public Imc(double altura, double peso)
    {
        this.altura = altura;
        this.peso = peso;                
    }
    
    public ArrayList<String> calcularImc()
    {
        ArrayList<String> datos = new ArrayList<>();
        double imc = ((this.peso)/(this.altura * this.altura));
        String calculo = imc + "";
        String tiene = "";
        datos.add(calculo);
        if(imc < 16.0)
        {
            tiene = "Magreza Grave";
        }
        else
        {
            if(imc >= 16.0 && imc < 17.0)
            {
                tiene = "Magreza Moderada";
            }
            else
            {
                if(imc >= 17.0 && imc < 18.5)
                {
                    tiene = "Magreza Leve";
                }
                else
                {
                    if(imc >= 18.5 && imc < 24.5)
                    {
                        tiene = "Saudável";
                    }
                    else
                    {
                        if(imc >= 25.0 && imc <30.0)
                        {
                            tiene = "Sobrepeso";
                        }
                        else
                        {
                            if(imc >= 30.0 && imc < 35.0)
                            {
                                tiene = "Obesidade Grau I";
                            }
                            else
                            {
                                if(imc >= 35 && imc < 40.0)
                                {
                                    tiene = "Obsidade Grau II (Severa)";
                                }
                                else
                                {
                                    tiene = "Obesidade Grau III (Mórbida)";
                                }
                            }
                        }
                    }
                }
            }
        }
        datos.add(tiene);
                
        return datos;
    }

    public void setAltura(double altura) 
    {
        this.altura = altura;
    }

    public void setPeso(double peso) 
    {
        this.peso = peso;
    }
    
    
    
}
