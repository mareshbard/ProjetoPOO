/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.login.dao;

import br.edu.login.view.CadastroView;
import br.edu.login.view.TelaEscolha;
import br.edu.login.view.LoginView;
import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class LoginDAO {

    public static boolean Teste;

public void Cheshire(Boolean x){
x = true;
System.out.println("Teste");
}



public void testar(){
        int teste = 1;
}

    public void cadastrarUsuario(String nome, String senha) throws SQLException {
        Connection conexao = new Conexao().getConnection();
        String sql = "INSERT INTO login (nome, senha) VALUES ('" + nome + "', '" + senha + "')";
        System.out.println(sql);
        PreparedStatement statment = conexao.prepareStatement(sql);
        statment.execute();
        conexao.close();

    }

    LoginView telaDeLogin3 = new LoginView();
 LoginView loginlegal = new LoginView();

    public void login(String nome, String senha) throws SQLException {
        Connection conexao = new Conexao().getConnection();
        String sql = "SELECT nome,senha FROM login WHERE nome = '" + nome + "' AND senha = '" + senha + "'";
        System.out.println(sql);
        PreparedStatement statment = conexao.prepareStatement(sql);
        ResultSet rs = statment.executeQuery();

        if (rs.next()) {
            System.out.println("Possui");
            Teste = true;
            TelaEscolha teste = new TelaEscolha();
            teste.setVisible(true);
            Component rootPane = null;
           JOptionPane.showMessageDialog(rootPane, "Login realizado com sucesso.");


        } else {
            System.out.println("Não possui");
            Teste = false;
            Component rootPane2 = null;
            JOptionPane.showMessageDialog(rootPane2, "Login ou senha incorretos.");

        }

    }

}
