/*
 
 */
package br.edu.login.controller;

import br.edu.login.dao.Conexao;
import br.edu.login.dao.LoginDAO;
import br.edu.login.view.CadastroView;
import br.edu.login.view.LoginView;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class LoginController {


public void cadastroUsuario(CadastroView view) throws SQLException{

Connection conexao = new Conexao().getConnection();
LoginDAO cadastro = new LoginDAO();
cadastro.cadastrarUsuario(view.getCampoLogin().getText(), view.getCampoSenha1().getText());



}


public void loginUsuario(LoginView view) throws SQLException{

Connection conexao = new Conexao().getConnection();
LoginDAO login = new LoginDAO();
login.login(view.getCampLog().getText(), view.getCampSen().getText());



}


}
